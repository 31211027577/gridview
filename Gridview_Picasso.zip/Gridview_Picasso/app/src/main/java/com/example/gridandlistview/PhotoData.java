package com.example.gridandlistview;

import java.util.ArrayList;

public class PhotoData {
    public static ArrayList<Photo> generatePhotoData(){
        ArrayList<Photo> photos = new ArrayList<>();

        photos.add(new Photo(0,
                "https://static.wikia.nocookie.net/leagueoflegends/images/3/39/Yasuo_OriginalSkin.jpg/revision/latest?cb=20181021032917",
                "Yasuo","Lmao champ in League"));
        photos.add(new Photo(1,
                "https://static.wikia.nocookie.net/leagueoflegends/images/9/95/Yone_OriginalSkin.jpg/revision/latest?cb=20210923014252",
                "Yone","Yasuo's brother who sit on a wheelchair"));
        photos.add(new Photo(2,
                "https://static.wikia.nocookie.net/leagueoflegends/images/5/5a/Briar_Render.png/revision/latest?cb=20230831013024",
                "Briar","Tù ko tả dc"));


        return photos;
    }

    public static Photo getPhotoFromID(int id){
        ArrayList<Photo> phs = generatePhotoData();
        for (int i = 0;i<phs.size();i++)
            if (phs.get(i).getId() == id)
                return phs.get(i);
        return null;
    }
}
